SERP Analysis kit from Brandella Journal

Files:
  brandella-serp-analysis-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-serp-analysis-guide.pdf       Full guide
  brandella-serp-analysis-checklist.pdf   Printable checklist
  brandella-serp-analysis-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/serp-analysis/
Free for personal and client work.
