Keyword Research kit from Brandella Journal

Files:
  brandella-keyword-research-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-keyword-research-guide.pdf       Full guide
  brandella-keyword-research-checklist.pdf   Printable checklist
  brandella-keyword-research-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/keyword-research/
Free for personal and client work.
