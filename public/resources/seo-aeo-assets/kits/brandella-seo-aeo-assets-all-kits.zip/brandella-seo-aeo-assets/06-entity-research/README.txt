Entity Research kit from Brandella Journal

Files:
  brandella-entity-research-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-entity-research-guide.pdf       Full guide
  brandella-entity-research-checklist.pdf   Printable checklist
  brandella-entity-research-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/entity-research/
Free for personal and client work.
