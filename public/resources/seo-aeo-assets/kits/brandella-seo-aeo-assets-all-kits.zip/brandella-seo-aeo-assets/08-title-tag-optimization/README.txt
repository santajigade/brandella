Title Tag Optimization kit from Brandella Journal

Files:
  brandella-title-tag-optimization-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-title-tag-optimization-guide.pdf       Full guide
  brandella-title-tag-optimization-checklist.pdf   Printable checklist
  brandella-title-tag-optimization-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/title-tag-optimization/
Free for personal and client work.
