Internal Linking kit from Brandella Journal

Files:
  brandella-internal-linking-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-internal-linking-guide.pdf       Full guide
  brandella-internal-linking-checklist.pdf   Printable checklist
  brandella-internal-linking-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/internal-linking/
Free for personal and client work.
