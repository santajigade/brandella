On-Page SEO kit from Brandella Journal

Files:
  brandella-on-page-seo-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-on-page-seo-guide.pdf       Full guide
  brandella-on-page-seo-checklist.pdf   Printable checklist
  brandella-on-page-seo-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/on-page-seo/
Free for personal and client work.
