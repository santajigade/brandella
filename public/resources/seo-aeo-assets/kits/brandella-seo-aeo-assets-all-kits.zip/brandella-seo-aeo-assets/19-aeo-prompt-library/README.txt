AEO Prompt Library kit from Brandella Journal

Files:
  brandella-aeo-prompt-library-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-aeo-prompt-library-guide.pdf       Full guide
  brandella-aeo-prompt-library-checklist.pdf   Printable checklist
  brandella-aeo-prompt-library-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/aeo-prompt-library/
Free for personal and client work.
