Content Refreshes kit from Brandella Journal

Files:
  brandella-content-refreshes-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-content-refreshes-guide.pdf       Full guide
  brandella-content-refreshes-checklist.pdf   Printable checklist
  brandella-content-refreshes-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/content-refreshes/
Free for personal and client work.
