Blog Briefs kit from Brandella Journal

Files:
  brandella-blog-briefs-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-blog-briefs-guide.pdf       Full guide
  brandella-blog-briefs-checklist.pdf   Printable checklist
  brandella-blog-briefs-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/blog-briefs/
Free for personal and client work.
