Site Speed Wins kit from Brandella Journal

Files:
  brandella-site-speed-wins-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-site-speed-wins-guide.pdf       Full guide
  brandella-site-speed-wins-checklist.pdf   Printable checklist
  brandella-site-speed-wins-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/site-speed-wins/
Free for personal and client work.
