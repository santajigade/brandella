Crawlability Checks kit from Brandella Journal

Files:
  brandella-crawlability-checks-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-crawlability-checks-guide.pdf       Full guide
  brandella-crawlability-checks-checklist.pdf   Printable checklist
  brandella-crawlability-checks-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/crawlability-checks/
Free for personal and client work.
