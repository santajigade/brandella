Search Intent kit from Brandella Journal

Files:
  brandella-search-intent-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-search-intent-guide.pdf       Full guide
  brandella-search-intent-checklist.pdf   Printable checklist
  brandella-search-intent-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/search-intent/
Free for personal and client work.
