Competitor Gaps kit from Brandella Journal

Files:
  brandella-competitor-gaps-template.xlsx   Excel workbook (also opens in Google Sheets)
  brandella-competitor-gaps-guide.pdf       Full guide
  brandella-competitor-gaps-checklist.pdf   Printable checklist
  brandella-competitor-gaps-ai-prompts.md   AI prompt pack

Start with the "Start Here" tab in the workbook.
Online version: https://brandella.in/resources/seo-aeo-assets/competitor-gaps/
Free for personal and client work.
